package com.projeto.controller;

import com.projeto.model.Sentimento;
import com.projeto.service.SentimentoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/sentimentos")
@CrossOrigin(origins = "http://localhost:3000")  
public class SentimentoController {

    @Autowired
    private SentimentoService sentimentoService;

    @PostMapping("/salvar")
    public Sentimento salvarSentimento(@RequestBody Sentimento sentimento) {
        return sentimentoService.salvarSentimento(sentimento);
    }

    @GetMapping("/todos")
    public List<Sentimento> getTodosSentimentos() {
        return sentimentoService.getTodosSentimentos();
    }
}
