package com.projeto.service;

import com.projeto.model.Sentimento;
import com.projeto.repository.SentimentoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SentimentoService {

    @Autowired
    private SentimentoRepository sentimentoRepository;

    public Sentimento salvarSentimento(Sentimento sentimento) {
        return sentimentoRepository.save(sentimento);
    }

    public List<Sentimento> getTodosSentimentos() {
        return sentimentoRepository.findAll();
    }
}
