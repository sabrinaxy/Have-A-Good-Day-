package com.projeto.repository;

import com.projeto.model.Sentimento;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SentimentoRepository extends JpaRepository<Sentimento, Long> {
}
