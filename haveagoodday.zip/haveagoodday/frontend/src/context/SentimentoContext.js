import React, { createContext, useState, useContext } from 'react';

const SentimentoContext = createContext();

export const SentimentoProvider = ({ children }) => {
  const [sentimento, setSentimento] = useState(null); 

  const escolherSentimento = (novoSentimento) => {
    setSentimento(novoSentimento);
  };

  return (
    <SentimentoContext.Provider value={{ sentimento, escolherSentimento }}>
      {children}
    </SentimentoContext.Provider>
  );
};

export const useSentimento = () => {
  return useContext(SentimentoContext);
};
