import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { SentimentoProvider } from './context/SentimentoContext'; 

import Sentimentos from './components/Sentimentos';
import DescricaoSentimento from './components/DescricaoSentimento';
import MenuPrincipal from './components/MenuPrincipal';
import Calendario from './components/Calendario';
import Escrita from './components/Escrita';
import Respiracao from './components/Respiracao';
import Emergencia from './components/Emergencia';

function App() {
  return (
    <SentimentoProvider>
      <Router>
        <Routes>
          {/* Rota para a tela inicial de sentimentos */}
          <Route path="/" element={<Sentimentos />} />
          
          {/* Rota para a tela de descrição do sentimento */}
          <Route path="/descricao" element={<DescricaoSentimento />} />
          
          {/* Menu principal com links para outras telas */}
          <Route path="/menu" element={<MenuPrincipal />} />
          
          {/* Calendário com registros dos sentimentos */}
          <Route path="/calendario" element={<Calendario />} />
          
          {/* Tela de escrita para adicionar mais informações sobre o dia */}
          <Route path="/escrita" element={<Escrita />} />
          
          {/* Tela de respiração com links para vídeos de exercícios */}
          <Route path="/respiracao" element={<Respiracao />} />
          
          {/* Tela de emergência com informações de contato */}
          <Route path="/emergencia" element={<Emergencia />} />
        </Routes>
      </Router>
    </SentimentoProvider>
  );
}

export default App;
