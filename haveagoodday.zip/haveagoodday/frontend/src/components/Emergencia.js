import React from 'react';
import { useNavigate } from 'react-router-dom';
import './style.css'; 

const Emergencia = () => {
  const navigate = useNavigate();

  const contatosDeEmergencia = [
    { nome: 'Centro de Valorização da Vida (CVV)', telefone: '188', descricao: 'Atendimento psicológico gratuito e sigiloso 24h.' },
    { nome: 'Samu', telefone: '192', descricao: 'Serviço de Atendimento Móvel de Urgência - Emergências médicas.' },
    { nome: 'Polícia Militar', telefone: '190', descricao: 'Atendimento em casos de violência ou emergência de segurança pública.' },
  ];

  const voltarAoMenu = () => {
    navigate('/menu');
  };

  return (
    <div className="emergencia-container">
      <h1>Emergência - Contatos e Centros de Ajuda</h1>
      
      <h3>Contatos de Emergência</h3>
      <div className="contatos-lista">
        {contatosDeEmergencia.map((contato, index) => (
          <div key={index} className="contato-item">
            <h4>{contato.nome}</h4>
            <p><strong>Telefone:</strong> {contato.telefone}</p>
            <p><strong>Descrição:</strong> {contato.descricao}</p>
          </div>
        ))}
      </div>
      
      {/* Botão para voltar ao menu */}
      <button className="btn voltar" onClick={voltarAoMenu}>Voltar ao Menu</button>
    </div>
  );
};

export default Emergencia;
