import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './style.css'; 

const DescricaoSentimento = () => {
  const [descricao, setDescricao] = useState('');

  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    const sentimento = {
      feeling: 'feliz',  
      descricao: descricao
    };

    try {
      const response = await fetch('http://localhost:8080/api/sentimentos/salvar', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(sentimento),
      });


      if (response.ok) {
        console.log('Sentimento registrado com sucesso');
        navigate('/menu');  
      } else {
        console.error('Erro ao registrar sentimento');
      }
    } catch (error) {
      console.error('Erro na requisição', error);
    }
  };

  return (
    <div className="container">
      <h1>Descreva como foi o seu dia e por que você se sente assim</h1>
      
      {/* Campo de texto para a descrição */}
      <textarea
        value={descricao}
        onChange={(e) => setDescricao(e.target.value)}  
        rows="6"
        cols="50"
        placeholder="Digite aqui sua descrição..."
        required
      />

      {/* Botões de ação */}
      <div className="button-container">
        <button className="btn" onClick={handleSubmit}>Concluir</button>
        <button className="btn" onClick={() => navigate('/menu')}>Voltar para o menu</button>
      </div>
    </div>
  );
};

export default DescricaoSentimento;
