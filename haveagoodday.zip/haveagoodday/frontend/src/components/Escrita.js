import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './style.css';  

const Escrita = () => {
  const navigate = useNavigate();

  const [textoEscrito, setTextoEscrito] = useState('');

  const salvarEscrita = async () => {
   
    const dataAtual = new Date().toISOString().split('T')[0]; 

    const novaEscrita = {
      data: dataAtual,
      descricao: textoEscrito,
    };

    try {
    
      const response = await fetch('http://localhost:8080/api/escrita', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(novaEscrita),
      });

      if (response.ok) {
        alert('Escrita salva com sucesso!');
      } else {
        alert('Erro ao salvar escrita.');
      }
    } catch (error) {
      console.error('Erro ao enviar escrita:', error);
      alert('Erro de conexão. Tente novamente.');
    }
  };

  const handleTextoChange = (event) => {
    setTextoEscrito(event.target.value);
  };

  const voltarAoMenu = () => {
    navigate('/menu');
  };

  return (
    <div className="escrita-container">
      <h1>Escreva sobre o seu dia</h1>

      <textarea
        value={textoEscrito}
        onChange={handleTextoChange}
        placeholder="Escreva aqui..."
        rows="10"
        cols="50"
        className="textarea-escrita"
      />

      <div className="botoes-escrita">
        <button className="btn salvar" onClick={salvarEscrita}>
          Salvar
        </button>
        <button className="btn voltar" onClick={voltarAoMenu}>
          Voltar ao Menu
        </button>
      </div>
    </div>
  );
};

export default Escrita;
