import React from 'react';
import { useNavigate } from 'react-router-dom';
import './style.css';  

const MenuPrincipal = () => {
  const navigate = useNavigate();

  const irParaCalendario = () => {
    navigate('/calendario');
  };

  const irParaEscrita = () => {
    navigate('/escrita');
  };

  const irParaRespiracao = () => {
    navigate('/respiracao');
  };

  const irParaEmergencia = () => {
    navigate('/emergencia');
  };

  return (
    <div className="menu-principal-container">
      <h1>Menu Principal</h1>

      <div className="menu-buttons">
        <button className="btn menu-btn" onClick={irParaCalendario}>Calendário Pessoal</button>
        <button className="btn menu-btn" onClick={irParaEscrita}>Escrita</button>
        <button className="btn menu-btn" onClick={irParaRespiracao}>Exercícios de Respiração</button>
        <button className="btn menu-btn" onClick={irParaEmergencia}>Emergência</button>
      </div>
    </div>
  );
};

export default MenuPrincipal;
