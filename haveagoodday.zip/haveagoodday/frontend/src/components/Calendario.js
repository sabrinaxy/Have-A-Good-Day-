
import React, { useState } from 'react';
import './style.css'; 

const Calendario = () => {  
  const [selectedDate, setSelectedDate] = useState(null);  

  const handleDateChange = (newDate) => {
    setSelectedDate(newDate); 
  };

  return (
    <div className="calendar">
      <h1>Calendário</h1>  {/* Título do calendário */}
      
      {/* Exibe a data selecionada ou uma mensagem caso nenhuma data tenha sido selecionada */}
      <div>{selectedDate ? `Data selecionada: ${selectedDate}` : "Nenhuma data selecionada"}</div>

      {/* Botão que simula a seleção de uma data */}
      <button onClick={() => handleDateChange("2024-11-27")}>Selecionar data</button>  
    </div>
  );
};

export default Calendario;  
