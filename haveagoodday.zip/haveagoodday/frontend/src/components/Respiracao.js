import React from 'react';
import { useNavigate } from 'react-router-dom';
import './style.css'; 

const Respiracao = () => {
  const navigate = useNavigate();

  const voltarAoMenu = () => {
    navigate('/menu');
  };

  return (
    <div className="respiracao-container">
      <h1>Exercícios de Respiração</h1>
      
      <p>Escolha um vídeo abaixo para praticar seus exercícios de respiração:</p>

      <div className="respiracao-videos">
        <div className="video-card">
          <h2>Exercício de Respiração 1</h2>
          <iframe 
            width="560" 
            height="315" 
            src="https://www.youtube.com/embed/2nQ9Oq0eZbM" 
            title="Exercício de Respiração 1"
            frameBorder="0"
            allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          ></iframe>
        </div>

        <div className="video-card">
          <h2>Exercício de Respiração 2</h2>
          <iframe 
            width="560" 
            height="315" 
            src="https://www.youtube.com/embed/d1pDTsMxP4Y" 
            title="Exercício de Respiração 2"
            frameBorder="0"
            allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          ></iframe>
        </div>

        <div className="video-card">
          <h2>Exercício de Respiração 3</h2>
          <iframe 
            width="560" 
            height="315" 
            src="https://www.youtube.com/embed/Z2Km6t9AxtY" 
            title="Exercício de Respiração 3"
            frameBorder="0"
            allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          ></iframe>
        </div>
      </div>

      <button className="btn voltar" onClick={voltarAoMenu}>
        Voltar ao Menu
      </button>
    </div>
  );
};

export default Respiracao;
