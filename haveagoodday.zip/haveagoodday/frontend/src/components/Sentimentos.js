import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './style.css';

const Sentimentos = () => {
  const [sentimentoEscolhido, setSentimentoEscolhido] = useState(null);
  const navigate = useNavigate();

  const irParaDescricao = () => {
    if (sentimentoEscolhido) {
      navigate('/descricao', { state: { sentimento: sentimentoEscolhido } });
    } else {
      alert('Por favor, selecione um sentimento.');
    }
  };

  const pularEtapa = () => {
    navigate('/menu');
  };

  const selecionarSentimento = (sentimento) => {
    setSentimentoEscolhido(sentimento);
  };

  return (
    <div className="sentimentos-container">
      <h1>Como você está se sentindo hoje?</h1>
      
      <div className="sentimentos-emojis">
        <div className="emoji" onClick={() => selecionarSentimento('😊')}>
          <span role="img" aria-label="Feliz">😊</span>
        </div>
        <div className="emoji" onClick={() => selecionarSentimento('😔')}>
          <span role="img" aria-label="Triste">😔</span>
        </div>
        <div className="emoji" onClick={() => selecionarSentimento('😡')}>
          <span role="img" aria-label="Raiva">😡</span>
        </div>
        <div className="emoji" onClick={() => selecionarSentimento('😴')}>
          <span role="img" aria-label="Cansado">😴</span>
        </div>
        <div className="emoji" onClick={() => selecionarSentimento('😨')}>
          <span role="img" aria-label="Assustado">😨</span>
        </div>
        <div className="emoji" onClick={() => selecionarSentimento('🤔')}>
          <span role="img" aria-label="Pensativo">🤔</span>
        </div>
      </div>

      <div className="actions">
        <button className="btn concluir" onClick={irParaDescricao}>
          Concluído
        </button>
        <button className="btn pular" onClick={pularEtapa}>
          Agora não
        </button>
      </div>
    </div>
  );
};

export default Sentimentos;
