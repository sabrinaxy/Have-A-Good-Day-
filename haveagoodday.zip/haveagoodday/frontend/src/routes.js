import React from 'react';
import { Route } from 'react-router-dom'; 
import Sentimentos from './components/Sentimentos';  
import DescricaoSentimento from './components/DescricaoSentimento'; 
import MenuPrincipal from './components/MenuPrincipal';  
import Calendario from './components/Calendario'; 
import Escrita from './components/Escrita';  
import Respiracao from './components/Respiracao';  
import Emergencia from './components/Emergencia';  

const Routes = () => {
  return (
    <>
      <Route path="/" element={<Sentimentos />} />
      <Route path="/descricao" element={<DescricaoSentimento />} />
      <Route path="/menu" element={<MenuPrincipal />} />
      <Route path="/calendario" element={<Calendario />} />
      <Route path="/escrita" element={<Escrita />} />
      <Route path="/respiracao" element={<Respiracao />} />
      <Route path="/emergencia" element={<Emergencia />} />
    </>
  );
}

export default Routes;
